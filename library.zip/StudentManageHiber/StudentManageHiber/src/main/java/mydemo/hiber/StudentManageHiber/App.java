package mydemo.hiber.StudentManageHiber;

import mydemo.hiber.StudentManageHiber.service.StudentService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StudentService studentservice=new StudentService();
    	studentservice.insertOp();
    	
    }
}
