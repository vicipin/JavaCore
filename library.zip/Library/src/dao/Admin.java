package dao;
import java.util.*;

public class Admin {
	
	private List<Libraian> LibList;

	public List<Libraian> getLibList() {
		return LibList;
	}

	public void setLibList(List<Libraian> libList) {
		LibList = libList;
	}

}
