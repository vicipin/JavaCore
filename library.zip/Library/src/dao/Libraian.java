package dao;

public class Libraian {
	
	private int liberianId;
	private String librarianname;
	private double salary;
	private int qualifications;
	public int getLiberianId() {
		return liberianId;
	}
	public void setLiberianId(int liberianId) {
		this.liberianId = liberianId;
	}
	public String getLibrarianname() {
		return librarianname;
	}
	public void setLibrarianname(String librarianname) {
		this.librarianname = librarianname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getQualifications() {
		return qualifications;
	}
	public void setQualifications(int qualifications) {
		this.qualifications = qualifications;
	}
	

}
